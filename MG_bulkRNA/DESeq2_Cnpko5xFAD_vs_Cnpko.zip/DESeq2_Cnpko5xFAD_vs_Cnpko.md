```R
#2020, Ting Sun
#for Depp and Sun et al manuscript
#microglia bulk RNA sequencing
#raw fastq files aligned to reference genome using STAR default parameters
#gene counts extracted by featureCounts

#sequenced genotypes (6-month-old)
#WT, CnpKO, 5xFAD, CnpKO x 5xFAD

#apply differential expression analysis to every pair of genotypes (using CnpKOx5xFAD vs CnpKO as example )
#by DESeq2 package
#summarize statistic result

```


```R
library(dplyr)
library(DESeq2)
library(ggplot2)
```

    
    Attaching package: ‘dplyr’
    
    The following objects are masked from ‘package:stats’:
    
        filter, lag
    
    The following objects are masked from ‘package:base’:
    
        intersect, setdiff, setequal, union
    
    Loading required package: S4Vectors
    Loading required package: stats4
    Loading required package: BiocGenerics
    Loading required package: parallel
    
    Attaching package: ‘BiocGenerics’
    
    The following objects are masked from ‘package:parallel’:
    
        clusterApply, clusterApplyLB, clusterCall, clusterEvalQ,
        clusterExport, clusterMap, parApply, parCapply, parLapply,
        parLapplyLB, parRapply, parSapply, parSapplyLB
    
    The following objects are masked from ‘package:dplyr’:
    
        combine, intersect, setdiff, union
    
    The following objects are masked from ‘package:stats’:
    
        IQR, mad, sd, var, xtabs
    
    The following objects are masked from ‘package:base’:
    
        anyDuplicated, append, as.data.frame, basename, cbind, colnames,
        dirname, do.call, duplicated, eval, evalq, Filter, Find, get, grep,
        grepl, intersect, is.unsorted, lapply, Map, mapply, match, mget,
        order, paste, pmax, pmax.int, pmin, pmin.int, Position, rank,
        rbind, Reduce, rownames, sapply, setdiff, sort, table, tapply,
        union, unique, unsplit, which, which.max, which.min
    
    
    Attaching package: ‘S4Vectors’
    
    The following objects are masked from ‘package:dplyr’:
    
        first, rename
    
    The following object is masked from ‘package:base’:
    
        expand.grid
    
    Loading required package: IRanges
    
    Attaching package: ‘IRanges’
    
    The following objects are masked from ‘package:dplyr’:
    
        collapse, desc, slice
    
    Loading required package: GenomicRanges
    Loading required package: GenomeInfoDb
    Loading required package: SummarizedExperiment
    Loading required package: Biobase
    Welcome to Bioconductor
    
        Vignettes contain introductory material; view with
        'browseVignettes()'. To cite Bioconductor, see
        'citation("Biobase")', and for packages 'citation("pkgname")'.
    
    Loading required package: DelayedArray
    Loading required package: matrixStats
    
    Attaching package: ‘matrixStats’
    
    The following objects are masked from ‘package:Biobase’:
    
        anyMissing, rowMedians
    
    The following object is masked from ‘package:dplyr’:
    
        count
    
    Loading required package: BiocParallel
    
    Attaching package: ‘DelayedArray’
    
    The following objects are masked from ‘package:matrixStats’:
    
        colMaxs, colMins, colRanges, rowMaxs, rowMins, rowRanges
    
    The following objects are masked from ‘package:base’:
    
        aperm, apply, rowsum
    



```R
sessionInfo()
```


    R version 3.6.1 (2019-07-05)
    Platform: x86_64-conda_cos6-linux-gnu (64-bit)
    Running under: Ubuntu 20.04.2 LTS
    
    Matrix products: default
    BLAS/LAPACK: /home/tsun/anaconda3/envs/bulk/lib/R/lib/libRblas.so
    
    locale:
     [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C              
     [3] LC_TIME=en_US.UTF-8        LC_COLLATE=en_US.UTF-8    
     [5] LC_MONETARY=en_US.UTF-8    LC_MESSAGES=en_US.UTF-8   
     [7] LC_PAPER=en_US.UTF-8       LC_NAME=C                 
     [9] LC_ADDRESS=C               LC_TELEPHONE=C            
    [11] LC_MEASUREMENT=en_US.UTF-8 LC_IDENTIFICATION=C       
    
    attached base packages:
    [1] parallel  stats4    stats     graphics  grDevices utils     datasets 
    [8] methods   base     
    
    other attached packages:
     [1] ggplot2_3.3.2               DESeq2_1.26.0              
     [3] SummarizedExperiment_1.16.1 DelayedArray_0.12.3        
     [5] BiocParallel_1.20.1         matrixStats_0.56.0         
     [7] Biobase_2.46.0              GenomicRanges_1.38.0       
     [9] GenomeInfoDb_1.22.1         IRanges_2.20.2             
    [11] S4Vectors_0.24.4            BiocGenerics_0.32.0        
    [13] dplyr_1.0.2                
    
    loaded via a namespace (and not attached):
     [1] bit64_4.0.2            jsonlite_1.7.0         splines_3.6.1         
     [4] Formula_1.2-3          latticeExtra_0.6-29    blob_1.2.1            
     [7] GenomeInfoDbData_1.2.2 RSQLite_2.2.0          pillar_1.4.6          
    [10] backports_1.1.8        lattice_0.20-41        glue_1.4.1            
    [13] uuid_0.1-4             digest_0.6.25          RColorBrewer_1.1-2    
    [16] XVector_0.26.0         checkmate_2.0.0        colorspace_1.4-1      
    [19] htmltools_0.5.0        Matrix_1.2-18          XML_3.98-1.19         
    [22] pkgconfig_2.0.3        genefilter_1.68.0      zlibbioc_1.32.0       
    [25] purrr_0.3.4            xtable_1.8-4           scales_1.1.1          
    [28] jpeg_0.1-8.1           htmlTable_2.0.1        tibble_3.0.3          
    [31] annotate_1.64.0        generics_0.0.2         ellipsis_0.3.1        
    [34] withr_2.2.0            repr_1.1.0             nnet_7.3-14           
    [37] survival_3.2-3         magrittr_1.5           crayon_1.3.4          
    [40] memoise_1.1.0          evaluate_0.14          foreign_0.8-71        
    [43] tools_3.6.1            data.table_1.13.0      lifecycle_0.2.0       
    [46] stringr_1.4.0          locfit_1.5-9.4         munsell_0.5.0         
    [49] cluster_2.1.0          AnnotationDbi_1.48.0   compiler_3.6.1        
    [52] rlang_0.4.7            grid_3.6.1             RCurl_1.98-1.2        
    [55] pbdZMQ_0.3-3           IRkernel_0.8.15        rstudioapi_0.11       
    [58] htmlwidgets_1.5.1      bitops_1.0-6           base64enc_0.1-3       
    [61] gtable_0.3.0           DBI_1.1.0              R6_2.4.1              
    [64] gridExtra_2.3          knitr_1.29             bit_4.0.4             
    [67] Hmisc_4.4-1            stringi_1.4.6          IRdisplay_0.7.0       
    [70] Rcpp_1.0.5             geneplotter_1.64.0     vctrs_0.3.2           
    [73] rpart_4.1-15           png_0.1-7              tidyselect_1.1.0      
    [76] xfun_0.16             



```R
#read in raw counts matrix, sample meta.data list and gene annotation list
meta.data<-read.csv("./bulk_metadata.csv")
annot<-read.csv("./mouse_gene_ID_annotation.csv",
               stringsAsFactors = FALSE)
raw<-read.csv("./2020_AD_microglia_raw_counts.csv")
```


```R
meta.data
head(annot)
head(raw)
colnames(raw)
```


<table>
<caption>A data.frame: 16 × 5</caption>
<thead>
	<tr><th scope=col>X</th><th scope=col>file_name</th><th scope=col>seq_number</th><th scope=col>genotype</th><th scope=col>sample</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 1</td><td>p833s1_Nave_S42_L005_R1_001.fastq.gz.tabular </td><td> 1</td><td>WT       </td><td>WT_1        </td></tr>
	<tr><td> 9</td><td>p833s2_Nave_S43_L005_R1_001.fastq.gz.tabular </td><td> 2</td><td>WT       </td><td>WT_2        </td></tr>
	<tr><td>10</td><td>p833s3_Nave_S44_L005_R1_001.fastq.gz.tabular </td><td> 3</td><td>WT       </td><td>WT_3        </td></tr>
	<tr><td>11</td><td>p833s4_Nave_S45_L005_R1_001.fastq.gz.tabular </td><td> 4</td><td>WT       </td><td>WT_4        </td></tr>
	<tr><td>12</td><td>p833s5_Nave_S46_L005_R1_001.fastq.gz.tabular </td><td> 5</td><td>Cnp_ko   </td><td>Cnp_ko_5    </td></tr>
	<tr><td>13</td><td>p833s6_Nave_S47_L005_R1_001.fastq.gz.tabular </td><td> 6</td><td>Cnp_ko   </td><td>Cnp_ko_6    </td></tr>
	<tr><td>14</td><td>p833s7_Nave_S48_L005_R1_001.fastq.gz.tabular </td><td> 7</td><td>Cnp_ko   </td><td>Cnp_ko_7    </td></tr>
	<tr><td>15</td><td>p833s8_Nave_S49_L005_R1_001.fastq.gz.tabular </td><td> 8</td><td>Cnp_ko   </td><td>Cnp_ko_8    </td></tr>
	<tr><td>16</td><td>p833s9_Nave_S50_L005_R1_001.fastq.gz.tabular </td><td> 9</td><td>5xFAD    </td><td>5xFAD_9     </td></tr>
	<tr><td> 2</td><td>p833s10_Nave_S51_L005_R1_001.fastq.gz.tabular</td><td>10</td><td>5xFAD    </td><td>5xFAD_10    </td></tr>
	<tr><td> 3</td><td>p833s11_Nave_S52_L006_R1_001.fastq.gz.tabular</td><td>11</td><td>5xFAD    </td><td>5xFAD_11    </td></tr>
	<tr><td> 4</td><td>p833s12_Nave_S53_L006_R1_001.fastq.gz.tabular</td><td>12</td><td>5xFAD    </td><td>5xFAD_12    </td></tr>
	<tr><td> 5</td><td>p833s13_Nave_S54_L006_R1_001.fastq.gz.tabular</td><td>13</td><td>Cnp_5xFAD</td><td>Cnp_5xFAD_13</td></tr>
	<tr><td> 6</td><td>p833s14_Nave_S55_L006_R1_001.fastq.gz.tabular</td><td>14</td><td>Cnp_5xFAD</td><td>Cnp_5xFAD_14</td></tr>
	<tr><td> 7</td><td>p833s15_Nave_S56_L006_R1_001.fastq.gz.tabular</td><td>15</td><td>Cnp_5xFAD</td><td>Cnp_5xFAD_15</td></tr>
	<tr><td> 8</td><td>p833s16_Nave_S57_L006_R1_001.fastq.gz.tabular</td><td>16</td><td>Cnp_5xFAD</td><td>Cnp_5xFAD_16</td></tr>
</tbody>
</table>




<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>X</th><th scope=col>ensembl_gene_id</th><th scope=col>mgi_symbol</th><th scope=col>chromosome_name</th><th scope=col>strand</th><th scope=col>start_position</th><th scope=col>end_position</th><th scope=col>gene_biotype</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>1</td><td>ENSMUSG00000064336</td><td>mt-Tf  </td><td>MT</td><td>1</td><td>   1</td><td>  68</td><td>Mt_tRNA       </td></tr>
	<tr><th scope=row>2</th><td>2</td><td>ENSMUSG00000064337</td><td>mt-Rnr1</td><td>MT</td><td>1</td><td>  70</td><td>1024</td><td>Mt_rRNA       </td></tr>
	<tr><th scope=row>3</th><td>3</td><td>ENSMUSG00000064338</td><td>mt-Tv  </td><td>MT</td><td>1</td><td>1025</td><td>1093</td><td>Mt_tRNA       </td></tr>
	<tr><th scope=row>4</th><td>4</td><td>ENSMUSG00000064339</td><td>mt-Rnr2</td><td>MT</td><td>1</td><td>1094</td><td>2675</td><td>Mt_rRNA       </td></tr>
	<tr><th scope=row>5</th><td>5</td><td>ENSMUSG00000064340</td><td>mt-Tl1 </td><td>MT</td><td>1</td><td>2676</td><td>2750</td><td>Mt_tRNA       </td></tr>
	<tr><th scope=row>6</th><td>6</td><td>ENSMUSG00000064341</td><td>mt-Nd1 </td><td>MT</td><td>1</td><td>2751</td><td>3707</td><td>protein_coding</td></tr>
</tbody>
</table>




<table>
<caption>A data.frame: 6 × 18</caption>
<thead>
	<tr><th></th><th scope=col>X</th><th scope=col>gene_symbol</th><th scope=col>WT_1</th><th scope=col>WT_2</th><th scope=col>WT_3</th><th scope=col>WT_4</th><th scope=col>Cnp_ko_5</th><th scope=col>Cnp_ko_6</th><th scope=col>Cnp_ko_7</th><th scope=col>Cnp_ko_8</th><th scope=col>X5xFAD_9</th><th scope=col>X5xFAD_10</th><th scope=col>X5xFAD_11</th><th scope=col>X5xFAD_12</th><th scope=col>Cnp_5xFAD_13</th><th scope=col>Cnp_5xFAD_14</th><th scope=col>Cnp_5xFAD_15</th><th scope=col>Cnp_5xFAD_16</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>ENSMUSG00000000001</td><td>Gnai3</td><td>3535</td><td>3024</td><td>1589</td><td>2524</td><td>3886</td><td>1189</td><td>2897</td><td>1402</td><td>3142</td><td>3163</td><td>540</td><td>1241</td><td>1459</td><td>1162</td><td>1033</td><td>1067</td></tr>
	<tr><th scope=row>2</th><td>ENSMUSG00000000003</td><td>Pbsn </td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>3</th><td>ENSMUSG00000000028</td><td>Cdc45</td><td>  98</td><td>  60</td><td>  55</td><td>  59</td><td>  87</td><td>  14</td><td>  72</td><td>  34</td><td> 128</td><td> 134</td><td> 13</td><td>  45</td><td>  44</td><td>  38</td><td>  41</td><td>  28</td></tr>
	<tr><th scope=row>4</th><td>ENSMUSG00000000031</td><td>H19  </td><td>   1</td><td>   9</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   4</td><td>   0</td><td>   0</td><td>  0</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>5</th><td>ENSMUSG00000000037</td><td>Scml2</td><td>  36</td><td>   8</td><td>   0</td><td>  11</td><td>   7</td><td>   1</td><td>   0</td><td>  15</td><td>   3</td><td>  10</td><td>  9</td><td>   1</td><td>   4</td><td>   2</td><td>   0</td><td>   4</td></tr>
	<tr><th scope=row>6</th><td>ENSMUSG00000000049</td><td>Apoh </td><td>   2</td><td>   4</td><td>   5</td><td>   1</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>  0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td></tr>
</tbody>
</table>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'X'</li><li>'gene_symbol'</li><li>'WT_1'</li><li>'WT_2'</li><li>'WT_3'</li><li>'WT_4'</li><li>'Cnp_ko_5'</li><li>'Cnp_ko_6'</li><li>'Cnp_ko_7'</li><li>'Cnp_ko_8'</li><li>'X5xFAD_9'</li><li>'X5xFAD_10'</li><li>'X5xFAD_11'</li><li>'X5xFAD_12'</li><li>'Cnp_5xFAD_13'</li><li>'Cnp_5xFAD_14'</li><li>'Cnp_5xFAD_15'</li><li>'Cnp_5xFAD_16'</li></ol>




```R
rownames(raw)<-raw$X
rownames(meta.data)<-meta.data$sample
```


```R
colnames(raw)<-gsub("X","",colnames(raw))
colnames(raw)
```


<ol class=list-inline>
	<li>''</li>
	<li>'gene_symbol'</li>
	<li>'WT_1'</li>
	<li>'WT_2'</li>
	<li>'WT_3'</li>
	<li>'WT_4'</li>
	<li>'Cnp_ko_5'</li>
	<li>'Cnp_ko_6'</li>
	<li>'Cnp_ko_7'</li>
	<li>'Cnp_ko_8'</li>
	<li>'5xFAD_9'</li>
	<li>'5xFAD_10'</li>
	<li>'5xFAD_11'</li>
	<li>'5xFAD_12'</li>
	<li>'Cnp_5xFAD_13'</li>
	<li>'Cnp_5xFAD_14'</li>
	<li>'Cnp_5xFAD_15'</li>
	<li>'Cnp_5xFAD_16'</li>
</ol>




```R

```


```R
#####################select pair genotypes for analysis
#examplie using CnpKOx5xFAD vs CnpKO
sampleTable <- data.frame(sample = meta.data$sample[c(5:8,13:16)],
                         condition = meta.data$genotype[c(5:8,13:16)])
rownames(sampleTable)<-sampleTable$sample
```


```R
sampleTable
```


<table>
<caption>A data.frame: 8 × 2</caption>
<thead>
	<tr><th></th><th scope=col>sample</th><th scope=col>condition</th></tr>
	<tr><th></th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>Cnp_ko_5</th><td>Cnp_ko_5    </td><td>Cnp_ko   </td></tr>
	<tr><th scope=row>Cnp_ko_6</th><td>Cnp_ko_6    </td><td>Cnp_ko   </td></tr>
	<tr><th scope=row>Cnp_ko_7</th><td>Cnp_ko_7    </td><td>Cnp_ko   </td></tr>
	<tr><th scope=row>Cnp_ko_8</th><td>Cnp_ko_8    </td><td>Cnp_ko   </td></tr>
	<tr><th scope=row>Cnp_5xFAD_13</th><td>Cnp_5xFAD_13</td><td>Cnp_5xFAD</td></tr>
	<tr><th scope=row>Cnp_5xFAD_14</th><td>Cnp_5xFAD_14</td><td>Cnp_5xFAD</td></tr>
	<tr><th scope=row>Cnp_5xFAD_15</th><td>Cnp_5xFAD_15</td><td>Cnp_5xFAD</td></tr>
	<tr><th scope=row>Cnp_5xFAD_16</th><td>Cnp_5xFAD_16</td><td>Cnp_5xFAD</td></tr>
</tbody>
</table>




```R
colnames(raw)[1]<-"X"
rownames(raw)<-raw$X
cts<-raw[,rownames(sampleTable)]
head(cts)
```


<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Cnp_ko_5</th><th scope=col>Cnp_ko_6</th><th scope=col>Cnp_ko_7</th><th scope=col>Cnp_ko_8</th><th scope=col>Cnp_5xFAD_13</th><th scope=col>Cnp_5xFAD_14</th><th scope=col>Cnp_5xFAD_15</th><th scope=col>Cnp_5xFAD_16</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>ENSMUSG00000000001</th><td>3886</td><td>1189</td><td>2897</td><td>1402</td><td>1459</td><td>1162</td><td>1033</td><td>1067</td></tr>
	<tr><th scope=row>ENSMUSG00000000003</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>ENSMUSG00000000028</th><td>  87</td><td>  14</td><td>  72</td><td>  34</td><td>  44</td><td>  38</td><td>  41</td><td>  28</td></tr>
	<tr><th scope=row>ENSMUSG00000000031</th><td>   0</td><td>   0</td><td>   1</td><td>   4</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>ENSMUSG00000000037</th><td>   7</td><td>   1</td><td>   0</td><td>  15</td><td>   4</td><td>   2</td><td>   0</td><td>   4</td></tr>
	<tr><th scope=row>ENSMUSG00000000049</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td></tr>
</tbody>
</table>




```R
#apply DGE analysis using DESeq2 package
dds<-DESeqDataSetFromMatrix(countData = cts,
                                    colData = sampleTable,
                                    design = ~condition)
```

    factor levels were dropped which had no samples



```R
dds
```


    class: DESeqDataSet 
    dim: 55471 8 
    metadata(1): version
    assays(1): counts
    rownames(55471): ENSMUSG00000000001 ENSMUSG00000000003 ...
      ENSMUSG00000118639 ENSMUSG00000118640
    rowData names(0):
    colnames(8): Cnp_ko_5 Cnp_ko_6 ... Cnp_5xFAD_15 Cnp_5xFAD_16
    colData names(2): sample condition



```R
##############
dds$condition<-relevel(dds$condition, ref = "Cnp_ko")
```


```R
dds_result<-DESeq(dds)
```

    estimating size factors
    estimating dispersions
    gene-wise dispersion estimates
    mean-dispersion relationship
    final dispersion estimates
    fitting model and testing



```R
#extract statistic result
res<-results(dds_result)
```


```R
res
```


    log2 fold change (MLE): condition Cnp 5xFAD vs Cnp ko 
    Wald test p-value: condition Cnp 5xFAD vs Cnp ko 
    DataFrame with 55471 rows and 6 columns
                                baseMean      log2FoldChange             lfcSE
                               <numeric>           <numeric>         <numeric>
    ENSMUSG00000000001  1559.34046972118 -0.0157946066320022 0.143341505923618
    ENSMUSG00000000003                 0                  NA                NA
    ENSMUSG00000000028  41.5039282917149   0.574083870602662 0.356651256851704
    ENSMUSG00000000031  0.55939392700539   -2.18537903528362  3.39804162125527
    ENSMUSG00000000037  3.93900585635211  -0.546877269033553  1.35261680854946
    ...                              ...                 ...               ...
    ENSMUSG00000118636 0.707005692596459  -0.384721962735069  2.32242220331432
    ENSMUSG00000118637                 0                  NA                NA
    ENSMUSG00000118638                 0                  NA                NA
    ENSMUSG00000118639                 0                  NA                NA
    ENSMUSG00000118640                 0                  NA                NA
                                     stat            pvalue              padj
                                <numeric>         <numeric>         <numeric>
    ENSMUSG00000000001 -0.110188647246518 0.912259765632265 0.963621498304743
    ENSMUSG00000000003                 NA                NA                NA
    ENSMUSG00000000028   1.60965049070714 0.107474178976521 0.318894015042958
    ENSMUSG00000000031 -0.643128978060109 0.520140412771096                NA
    ENSMUSG00000000037 -0.404310567173878 0.685984355799904 0.848702469448824
    ...                               ...               ...               ...
    ENSMUSG00000118636 -0.165655479088184 0.868428084402659                NA
    ENSMUSG00000118637                 NA                NA                NA
    ENSMUSG00000118638                 NA                NA                NA
    ENSMUSG00000118639                 NA                NA                NA
    ENSMUSG00000118640                 NA                NA                NA



```R
exp<-res
########################
colnames(exp)<-paste0("Cnp5xFAD_vs_Cnpko_",colnames(res))
```


```R
exp
```


     
     
    DataFrame with 55471 rows and 6 columns
                       Cnp5xFAD_vs_Cnpko_baseMean Cnp5xFAD_vs_Cnpko_log2FoldChange
                                        <numeric>                        <numeric>
    ENSMUSG00000000001           1559.34046972118              -0.0157946066320022
    ENSMUSG00000000003                          0                               NA
    ENSMUSG00000000028           41.5039282917149                0.574083870602662
    ENSMUSG00000000031           0.55939392700539                -2.18537903528362
    ENSMUSG00000000037           3.93900585635211               -0.546877269033553
    ...                                       ...                              ...
    ENSMUSG00000118636          0.707005692596459               -0.384721962735069
    ENSMUSG00000118637                          0                               NA
    ENSMUSG00000118638                          0                               NA
    ENSMUSG00000118639                          0                               NA
    ENSMUSG00000118640                          0                               NA
                       Cnp5xFAD_vs_Cnpko_lfcSE Cnp5xFAD_vs_Cnpko_stat
                                     <numeric>              <numeric>
    ENSMUSG00000000001       0.143341505923618     -0.110188647246518
    ENSMUSG00000000003                      NA                     NA
    ENSMUSG00000000028       0.356651256851704       1.60965049070714
    ENSMUSG00000000031        3.39804162125527     -0.643128978060109
    ENSMUSG00000000037        1.35261680854946     -0.404310567173878
    ...                                    ...                    ...
    ENSMUSG00000118636        2.32242220331432     -0.165655479088184
    ENSMUSG00000118637                      NA                     NA
    ENSMUSG00000118638                      NA                     NA
    ENSMUSG00000118639                      NA                     NA
    ENSMUSG00000118640                      NA                     NA
                       Cnp5xFAD_vs_Cnpko_pvalue Cnp5xFAD_vs_Cnpko_padj
                                      <numeric>              <numeric>
    ENSMUSG00000000001        0.912259765632265      0.963621498304743
    ENSMUSG00000000003                       NA                     NA
    ENSMUSG00000000028        0.107474178976521      0.318894015042958
    ENSMUSG00000000031        0.520140412771096                     NA
    ENSMUSG00000000037        0.685984355799904      0.848702469448824
    ...                                     ...                    ...
    ENSMUSG00000118636        0.868428084402659                     NA
    ENSMUSG00000118637                       NA                     NA
    ENSMUSG00000118638                       NA                     NA
    ENSMUSG00000118639                       NA                     NA
    ENSMUSG00000118640                       NA                     NA



```R
#order result based on adjP
res<-res[order(res$padj, decreasing = F),]
```


```R
#filter result for significant regulated genes, use cut-off adjP<0.05
res
summary(res)

res_sig<-results(dds_result, alpha = 0.05)
summary(res_sig)
```


    log2 fold change (MLE): condition Cnp 5xFAD vs Cnp ko 
    Wald test p-value: condition Cnp 5xFAD vs Cnp ko 
    DataFrame with 55471 rows and 6 columns
                                baseMean     log2FoldChange             lfcSE
                               <numeric>          <numeric>         <numeric>
    ENSMUSG00000031425   1884.9767597741  -3.93671458581075 0.246014531516049
    ENSMUSG00000037625  191.173535462697  -3.67700504305091  0.29002690112374
    ENSMUSG00000026442  349.555460652756  -2.95661615135894 0.272163966199007
    ENSMUSG00000027375  244.379951793621  -2.57641876820185  0.26417957012007
    ENSMUSG00000018126  690.024090446332   2.81009755149968 0.294471382991884
    ...                              ...                ...               ...
    ENSMUSG00000118636 0.707005692596459 -0.384721962735069  2.32242220331432
    ENSMUSG00000118637                 0                 NA                NA
    ENSMUSG00000118638                 0                 NA                NA
    ENSMUSG00000118639                 0                 NA                NA
    ENSMUSG00000118640                 0                 NA                NA
                                     stat               pvalue                 padj
                                <numeric>            <numeric>            <numeric>
    ENSMUSG00000031425  -16.0019595653598 1.23815815301259e-57 2.53203342291075e-53
    ENSMUSG00000037625  -12.6781516776684 7.81530863230997e-37 7.99115307653694e-33
    ENSMUSG00000026442  -10.8633637018541 1.72283890899866e-27 1.17440185630076e-23
    ENSMUSG00000027375  -9.75252842992691 1.79930016777212e-22 9.19892210773498e-19
    ENSMUSG00000018126   9.54285446330492 1.38953971436719e-21 5.66844886138916e-18
    ...                               ...                  ...                  ...
    ENSMUSG00000118636 -0.165655479088184    0.868428084402659                   NA
    ENSMUSG00000118637                 NA                   NA                   NA
    ENSMUSG00000118638                 NA                   NA                   NA
    ENSMUSG00000118639                 NA                   NA                   NA
    ENSMUSG00000118640                 NA                   NA                   NA


    
    out of 30048 with nonzero total read count
    adjusted p-value < 0.1
    LFC > 0 (up)       : 1271, 4.2%
    LFC < 0 (down)     : 1241, 4.1%
    outliers [1]       : 136, 0.45%
    low counts [2]     : 9462, 31%
    (mean count < 1)
    [1] see 'cooksCutoff' argument of ?results
    [2] see 'independentFiltering' argument of ?results
    
    
    out of 30048 with nonzero total read count
    adjusted p-value < 0.05
    LFC > 0 (up)       : 756, 2.5%
    LFC < 0 (down)     : 841, 2.8%
    outliers [1]       : 136, 0.45%
    low counts [2]     : 9462, 31%
    (mean count < 1)
    [1] see 'cooksCutoff' argument of ?results
    [2] see 'independentFiltering' argument of ?results
    



```R
plotMA(res_sig, ylim = c(-10,10))
```


![png](output_21_0.png)



```R
mcols(res_sig)
```


    DataFrame with 6 rows and 2 columns
                           type
                    <character>
    baseMean       intermediate
    log2FoldChange      results
    lfcSE               results
    stat                results
    pvalue              results
    padj                results
                                                             description
                                                             <character>
    baseMean                   mean of normalized counts for all samples
    log2FoldChange log2 fold change (MLE): condition Cnp 5xFAD vs Cnp ko
    lfcSE                  standard error: condition Cnp 5xFAD vs Cnp ko
    stat                   Wald statistic: condition Cnp 5xFAD vs Cnp ko
    pvalue              Wald test p-value: condition Cnp 5xFAD vs Cnp ko
    padj                                            BH adjusted p-values



```R

#########################the following script aim to summarize statistics from CnpKOx5xFAD vs CnpKO
##########################together with gene raw counts and normalised counts

raw<-as.data.frame(counts(dds_result,normalized=F))
rld<-as.data.frame(counts(dds_result,normalized=T))
```


```R
head(raw)
head(rld)
```


<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Cnp_ko_5</th><th scope=col>Cnp_ko_6</th><th scope=col>Cnp_ko_7</th><th scope=col>Cnp_ko_8</th><th scope=col>Cnp_5xFAD_13</th><th scope=col>Cnp_5xFAD_14</th><th scope=col>Cnp_5xFAD_15</th><th scope=col>Cnp_5xFAD_16</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>ENSMUSG00000000001</th><td>3886</td><td>1189</td><td>2897</td><td>1402</td><td>1459</td><td>1162</td><td>1033</td><td>1067</td></tr>
	<tr><th scope=row>ENSMUSG00000000003</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>ENSMUSG00000000028</th><td>  87</td><td>  14</td><td>  72</td><td>  34</td><td>  44</td><td>  38</td><td>  41</td><td>  28</td></tr>
	<tr><th scope=row>ENSMUSG00000000031</th><td>   0</td><td>   0</td><td>   1</td><td>   4</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>ENSMUSG00000000037</th><td>   7</td><td>   1</td><td>   0</td><td>  15</td><td>   4</td><td>   2</td><td>   0</td><td>   4</td></tr>
	<tr><th scope=row>ENSMUSG00000000049</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td></tr>
</tbody>
</table>




<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Cnp_ko_5</th><th scope=col>Cnp_ko_6</th><th scope=col>Cnp_ko_7</th><th scope=col>Cnp_ko_8</th><th scope=col>Cnp_5xFAD_13</th><th scope=col>Cnp_5xFAD_14</th><th scope=col>Cnp_5xFAD_15</th><th scope=col>Cnp_5xFAD_16</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>ENSMUSG00000000001</th><td>1731.626017</td><td>1448.11835</td><td>1730.0963936</td><td>1359.221004</td><td>1716.147149</td><td>1541.692063</td><td>1540.968497</td><td>1406.854279</td></tr>
	<tr><th scope=row>ENSMUSG00000000003</th><td>   0.000000</td><td>   0.00000</td><td>   0.0000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td></tr>
	<tr><th scope=row>ENSMUSG00000000028</th><td>  38.767747</td><td>  17.05102</td><td>  42.9985987</td><td>  32.962564</td><td>  51.754952</td><td>  50.416780</td><td>  61.161383</td><td>  36.918388</td></tr>
	<tr><th scope=row>ENSMUSG00000000031</th><td>   0.000000</td><td>   0.00000</td><td>   0.5972028</td><td>   3.877949</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td></tr>
	<tr><th scope=row>ENSMUSG00000000037</th><td>   3.119244</td><td>   1.21793</td><td>   0.0000000</td><td>  14.542307</td><td>   4.704996</td><td>   2.653515</td><td>   0.000000</td><td>   5.274055</td></tr>
	<tr><th scope=row>ENSMUSG00000000049</th><td>   0.000000</td><td>   0.00000</td><td>   0.0000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   1.491741</td><td>   0.000000</td></tr>
</tbody>
</table>




```R
for (i in 1:8){
    colnames(raw)[[i]]<-paste0(colnames(raw)[[i]],".","raw_counts")
    colnames(rld)[[i]]<-paste0(colnames(rld)[[i]],".","_normalised_value")
}
```


```R
head(raw)
head(rld)
```


<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Cnp_ko_5.raw_counts</th><th scope=col>Cnp_ko_6.raw_counts</th><th scope=col>Cnp_ko_7.raw_counts</th><th scope=col>Cnp_ko_8.raw_counts</th><th scope=col>Cnp_5xFAD_13.raw_counts</th><th scope=col>Cnp_5xFAD_14.raw_counts</th><th scope=col>Cnp_5xFAD_15.raw_counts</th><th scope=col>Cnp_5xFAD_16.raw_counts</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>ENSMUSG00000000001</th><td>3886</td><td>1189</td><td>2897</td><td>1402</td><td>1459</td><td>1162</td><td>1033</td><td>1067</td></tr>
	<tr><th scope=row>ENSMUSG00000000003</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>ENSMUSG00000000028</th><td>  87</td><td>  14</td><td>  72</td><td>  34</td><td>  44</td><td>  38</td><td>  41</td><td>  28</td></tr>
	<tr><th scope=row>ENSMUSG00000000031</th><td>   0</td><td>   0</td><td>   1</td><td>   4</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td></tr>
	<tr><th scope=row>ENSMUSG00000000037</th><td>   7</td><td>   1</td><td>   0</td><td>  15</td><td>   4</td><td>   2</td><td>   0</td><td>   4</td></tr>
	<tr><th scope=row>ENSMUSG00000000049</th><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   0</td><td>   1</td><td>   0</td></tr>
</tbody>
</table>




<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th></th><th scope=col>Cnp_ko_5._normalised_value</th><th scope=col>Cnp_ko_6._normalised_value</th><th scope=col>Cnp_ko_7._normalised_value</th><th scope=col>Cnp_ko_8._normalised_value</th><th scope=col>Cnp_5xFAD_13._normalised_value</th><th scope=col>Cnp_5xFAD_14._normalised_value</th><th scope=col>Cnp_5xFAD_15._normalised_value</th><th scope=col>Cnp_5xFAD_16._normalised_value</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>ENSMUSG00000000001</th><td>1731.626017</td><td>1448.11835</td><td>1730.0963936</td><td>1359.221004</td><td>1716.147149</td><td>1541.692063</td><td>1540.968497</td><td>1406.854279</td></tr>
	<tr><th scope=row>ENSMUSG00000000003</th><td>   0.000000</td><td>   0.00000</td><td>   0.0000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td></tr>
	<tr><th scope=row>ENSMUSG00000000028</th><td>  38.767747</td><td>  17.05102</td><td>  42.9985987</td><td>  32.962564</td><td>  51.754952</td><td>  50.416780</td><td>  61.161383</td><td>  36.918388</td></tr>
	<tr><th scope=row>ENSMUSG00000000031</th><td>   0.000000</td><td>   0.00000</td><td>   0.5972028</td><td>   3.877949</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td></tr>
	<tr><th scope=row>ENSMUSG00000000037</th><td>   3.119244</td><td>   1.21793</td><td>   0.0000000</td><td>  14.542307</td><td>   4.704996</td><td>   2.653515</td><td>   0.000000</td><td>   5.274055</td></tr>
	<tr><th scope=row>ENSMUSG00000000049</th><td>   0.000000</td><td>   0.00000</td><td>   0.0000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   1.491741</td><td>   0.000000</td></tr>
</tbody>
</table>




```R
raw$gene_name<-rownames(raw)
rld$gene_name<-rownames(rld)
res$gene_name<-rownames(res)
```


```R
res<-as.data.frame(res[rownames(raw),])
```


```R
################################
colnames(res)[1:6]<-paste0("Cnp5xFAD_vs_Cnpko_",colnames(res)[1:6])
```


```R
pre<-merge(x = res, y = raw, by = "gene_name")
all<-merge(x = pre, y = rld, by = "gene_name")
```


```R
head(all)
```


<table>
<caption>A data.frame: 6 × 23</caption>
<thead>
	<tr><th scope=col>gene_name</th><th scope=col>Cnp5xFAD_vs_Cnpko_baseMean</th><th scope=col>Cnp5xFAD_vs_Cnpko_log2FoldChange</th><th scope=col>Cnp5xFAD_vs_Cnpko_lfcSE</th><th scope=col>Cnp5xFAD_vs_Cnpko_stat</th><th scope=col>Cnp5xFAD_vs_Cnpko_pvalue</th><th scope=col>Cnp5xFAD_vs_Cnpko_padj</th><th scope=col>Cnp_ko_5.raw_counts</th><th scope=col>Cnp_ko_6.raw_counts</th><th scope=col>Cnp_ko_7.raw_counts</th><th scope=col>⋯</th><th scope=col>Cnp_5xFAD_15.raw_counts</th><th scope=col>Cnp_5xFAD_16.raw_counts</th><th scope=col>Cnp_ko_5._normalised_value</th><th scope=col>Cnp_ko_6._normalised_value</th><th scope=col>Cnp_ko_7._normalised_value</th><th scope=col>Cnp_ko_8._normalised_value</th><th scope=col>Cnp_5xFAD_13._normalised_value</th><th scope=col>Cnp_5xFAD_14._normalised_value</th><th scope=col>Cnp_5xFAD_15._normalised_value</th><th scope=col>Cnp_5xFAD_16._normalised_value</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>⋯</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ENSMUSG00000000001</td><td>1559.3404697</td><td>-0.01579461</td><td>0.1433415</td><td>-0.1101886</td><td>0.9122598</td><td>0.9636215</td><td>3886</td><td>1189</td><td>2897</td><td>⋯</td><td>1033</td><td>1067</td><td>1731.626017</td><td>1448.11835</td><td>1730.0963936</td><td>1359.221004</td><td>1716.147149</td><td>1541.692063</td><td>1540.968497</td><td>1406.854279</td></tr>
	<tr><td>ENSMUSG00000000003</td><td>   0.0000000</td><td>         NA</td><td>       NA</td><td>        NA</td><td>       NA</td><td>       NA</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>   0</td><td>   0</td><td>   0.000000</td><td>   0.00000</td><td>   0.0000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td></tr>
	<tr><td>ENSMUSG00000000028</td><td>  41.5039283</td><td> 0.57408387</td><td>0.3566513</td><td> 1.6096505</td><td>0.1074742</td><td>0.3188940</td><td>  87</td><td>  14</td><td>  72</td><td>⋯</td><td>  41</td><td>  28</td><td>  38.767747</td><td>  17.05102</td><td>  42.9985987</td><td>  32.962564</td><td>  51.754952</td><td>  50.416780</td><td>  61.161383</td><td>  36.918388</td></tr>
	<tr><td>ENSMUSG00000000031</td><td>   0.5593939</td><td>-2.18537904</td><td>3.3980416</td><td>-0.6431290</td><td>0.5201404</td><td>       NA</td><td>   0</td><td>   0</td><td>   1</td><td>⋯</td><td>   0</td><td>   0</td><td>   0.000000</td><td>   0.00000</td><td>   0.5972028</td><td>   3.877949</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td></tr>
	<tr><td>ENSMUSG00000000037</td><td>   3.9390059</td><td>-0.54687727</td><td>1.3526168</td><td>-0.4043106</td><td>0.6859844</td><td>0.8487025</td><td>   7</td><td>   1</td><td>   0</td><td>⋯</td><td>   0</td><td>   4</td><td>   3.119244</td><td>   1.21793</td><td>   0.0000000</td><td>  14.542307</td><td>   4.704996</td><td>   2.653515</td><td>   0.000000</td><td>   5.274055</td></tr>
	<tr><td>ENSMUSG00000000049</td><td>   0.1864676</td><td> 1.54334765</td><td>3.5338115</td><td> 0.4367374</td><td>0.6623018</td><td>       NA</td><td>   0</td><td>   0</td><td>   0</td><td>⋯</td><td>   1</td><td>   0</td><td>   0.000000</td><td>   0.00000</td><td>   0.0000000</td><td>   0.000000</td><td>   0.000000</td><td>   0.000000</td><td>   1.491741</td><td>   0.000000</td></tr>
</tbody>
</table>




```R
#######################
all<-all[order(all$Cnp5xFAD_vs_Cnpko_padj, decreasing = F),]
```


```R
head(all)
```


<table>
<caption>A data.frame: 6 × 23</caption>
<thead>
	<tr><th></th><th scope=col>gene_name</th><th scope=col>Cnp5xFAD_vs_Cnpko_baseMean</th><th scope=col>Cnp5xFAD_vs_Cnpko_log2FoldChange</th><th scope=col>Cnp5xFAD_vs_Cnpko_lfcSE</th><th scope=col>Cnp5xFAD_vs_Cnpko_stat</th><th scope=col>Cnp5xFAD_vs_Cnpko_pvalue</th><th scope=col>Cnp5xFAD_vs_Cnpko_padj</th><th scope=col>Cnp_ko_5.raw_counts</th><th scope=col>Cnp_ko_6.raw_counts</th><th scope=col>Cnp_ko_7.raw_counts</th><th scope=col>⋯</th><th scope=col>Cnp_5xFAD_15.raw_counts</th><th scope=col>Cnp_5xFAD_16.raw_counts</th><th scope=col>Cnp_ko_5._normalised_value</th><th scope=col>Cnp_ko_6._normalised_value</th><th scope=col>Cnp_ko_7._normalised_value</th><th scope=col>Cnp_ko_8._normalised_value</th><th scope=col>Cnp_5xFAD_13._normalised_value</th><th scope=col>Cnp_5xFAD_14._normalised_value</th><th scope=col>Cnp_5xFAD_15._normalised_value</th><th scope=col>Cnp_5xFAD_16._normalised_value</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>⋯</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>8346</th><td>ENSMUSG00000031425</td><td>1884.9768</td><td>-3.936715</td><td>0.2460145</td><td>-16.001960</td><td>1.238158e-57</td><td>2.532033e-53</td><td>8325</td><td>3279</td><td>5729</td><td>⋯</td><td> 103</td><td> 273</td><td>3709.6723</td><td>3993.5913</td><td>3421.3746</td><td>3031.5864</td><td> 217.60605</td><td>192.37982</td><td> 153.64933</td><td> 359.95428</td></tr>
	<tr><th scope=row>10784</th><td>ENSMUSG00000037625</td><td> 191.1735</td><td>-3.677005</td><td>0.2900269</td><td>-12.678152</td><td>7.815309e-37</td><td>7.991153e-33</td><td> 891</td><td> 205</td><td> 537</td><td>⋯</td><td>  18</td><td>  29</td><td> 397.0352</td><td> 249.6756</td><td> 320.6979</td><td> 450.8115</td><td>  23.52498</td><td> 22.55488</td><td>  26.85134</td><td>  38.23690</td></tr>
	<tr><th scope=row>5551</th><td>ENSMUSG00000026442</td><td> 349.5555</td><td>-2.956616</td><td>0.2721640</td><td>-10.863364</td><td>1.722839e-27</td><td>1.174402e-23</td><td>2042</td><td> 498</td><td> 954</td><td>⋯</td><td>  49</td><td>  70</td><td> 909.9280</td><td> 606.5290</td><td> 569.7314</td><td> 390.7033</td><td>  70.57493</td><td> 83.58571</td><td>  73.09531</td><td>  92.29597</td></tr>
	<tr><th scope=row>6077</th><td>ENSMUSG00000027375</td><td> 244.3800</td><td>-2.576419</td><td>0.2641796</td><td> -9.752528</td><td>1.799300e-22</td><td>9.198922e-19</td><td> 965</td><td> 360</td><td> 634</td><td>⋯</td><td>  28</td><td>  76</td><td> 430.0101</td><td> 438.4547</td><td> 378.6265</td><td> 428.5133</td><td>  87.04242</td><td> 50.41678</td><td>  41.76875</td><td> 100.20705</td></tr>
	<tr><th scope=row>1883</th><td>ENSMUSG00000018126</td><td> 690.0241</td><td> 2.810098</td><td>0.2944714</td><td>  9.542854</td><td>1.389540e-21</td><td>5.668449e-18</td><td> 387</td><td> 168</td><td> 219</td><td>⋯</td><td>1193</td><td>1065</td><td> 172.4496</td><td> 204.6122</td><td> 130.7874</td><td> 182.2636</td><td>1008.04531</td><td>638.17029</td><td>1779.64706</td><td>1404.21725</td></tr>
	<tr><th scope=row>6343</th><td>ENSMUSG00000027858</td><td> 159.7806</td><td>-3.162569</td><td>0.3320560</td><td> -9.524204</td><td>1.663115e-21</td><td>5.668449e-18</td><td> 677</td><td> 290</td><td> 423</td><td>⋯</td><td>  16</td><td>  31</td><td> 301.6755</td><td> 353.1996</td><td> 252.6168</td><td> 243.3413</td><td>  49.40245</td><td> 13.26757</td><td>  23.86786</td><td>  40.87393</td></tr>
</tbody>
</table>




```R
head(annot)
```


<table>
<caption>A data.frame: 6 × 8</caption>
<thead>
	<tr><th scope=col>X</th><th scope=col>ensembl_gene_id</th><th scope=col>mgi_symbol</th><th scope=col>chromosome_name</th><th scope=col>strand</th><th scope=col>start_position</th><th scope=col>end_position</th><th scope=col>gene_biotype</th></tr>
	<tr><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>1</td><td>ENSMUSG00000064336</td><td>mt-Tf  </td><td>MT</td><td>1</td><td>   1</td><td>  68</td><td>Mt_tRNA       </td></tr>
	<tr><td>2</td><td>ENSMUSG00000064337</td><td>mt-Rnr1</td><td>MT</td><td>1</td><td>  70</td><td>1024</td><td>Mt_rRNA       </td></tr>
	<tr><td>3</td><td>ENSMUSG00000064338</td><td>mt-Tv  </td><td>MT</td><td>1</td><td>1025</td><td>1093</td><td>Mt_tRNA       </td></tr>
	<tr><td>4</td><td>ENSMUSG00000064339</td><td>mt-Rnr2</td><td>MT</td><td>1</td><td>1094</td><td>2675</td><td>Mt_rRNA       </td></tr>
	<tr><td>5</td><td>ENSMUSG00000064340</td><td>mt-Tl1 </td><td>MT</td><td>1</td><td>2676</td><td>2750</td><td>Mt_tRNA       </td></tr>
	<tr><td>6</td><td>ENSMUSG00000064341</td><td>mt-Nd1 </td><td>MT</td><td>1</td><td>2751</td><td>3707</td><td>protein_coding</td></tr>
</tbody>
</table>




```R
all$ensembl_ID<-all$gene_name
```


```R
for(i in 1:nrow(all)){
    position<-match(all$ensembl_ID[[i]], annot$ensembl_gene_id)
    all$gene_name[[i]]<-annot$mgi_symbol[position]
}
```


```R
head(all)
```


<table>
<caption>A data.frame: 6 × 24</caption>
<thead>
	<tr><th></th><th scope=col>gene_name</th><th scope=col>Cnp5xFAD_vs_Cnpko_baseMean</th><th scope=col>Cnp5xFAD_vs_Cnpko_log2FoldChange</th><th scope=col>Cnp5xFAD_vs_Cnpko_lfcSE</th><th scope=col>Cnp5xFAD_vs_Cnpko_stat</th><th scope=col>Cnp5xFAD_vs_Cnpko_pvalue</th><th scope=col>Cnp5xFAD_vs_Cnpko_padj</th><th scope=col>Cnp_ko_5.raw_counts</th><th scope=col>Cnp_ko_6.raw_counts</th><th scope=col>Cnp_ko_7.raw_counts</th><th scope=col>⋯</th><th scope=col>Cnp_5xFAD_16.raw_counts</th><th scope=col>Cnp_ko_5._normalised_value</th><th scope=col>Cnp_ko_6._normalised_value</th><th scope=col>Cnp_ko_7._normalised_value</th><th scope=col>Cnp_ko_8._normalised_value</th><th scope=col>Cnp_5xFAD_13._normalised_value</th><th scope=col>Cnp_5xFAD_14._normalised_value</th><th scope=col>Cnp_5xFAD_15._normalised_value</th><th scope=col>Cnp_5xFAD_16._normalised_value</th><th scope=col>ensembl_ID</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>⋯</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>8346</th><td>Plp1    </td><td>1884.9768</td><td>-3.936715</td><td>0.2460145</td><td>-16.001960</td><td>1.238158e-57</td><td>2.532033e-53</td><td>8325</td><td>3279</td><td>5729</td><td>⋯</td><td> 273</td><td>3709.6723</td><td>3993.5913</td><td>3421.3746</td><td>3031.5864</td><td> 217.60605</td><td>192.37982</td><td> 153.64933</td><td> 359.95428</td><td>ENSMUSG00000031425</td></tr>
	<tr><th scope=row>10784</th><td>Cldn11  </td><td> 191.1735</td><td>-3.677005</td><td>0.2900269</td><td>-12.678152</td><td>7.815309e-37</td><td>7.991153e-33</td><td> 891</td><td> 205</td><td> 537</td><td>⋯</td><td>  29</td><td> 397.0352</td><td> 249.6756</td><td> 320.6979</td><td> 450.8115</td><td>  23.52498</td><td> 22.55488</td><td>  26.85134</td><td>  38.23690</td><td>ENSMUSG00000037625</td></tr>
	<tr><th scope=row>5551</th><td>Nfasc   </td><td> 349.5555</td><td>-2.956616</td><td>0.2721640</td><td>-10.863364</td><td>1.722839e-27</td><td>1.174402e-23</td><td>2042</td><td> 498</td><td> 954</td><td>⋯</td><td>  70</td><td> 909.9280</td><td> 606.5290</td><td> 569.7314</td><td> 390.7033</td><td>  70.57493</td><td> 83.58571</td><td>  73.09531</td><td>  92.29597</td><td>ENSMUSG00000026442</td></tr>
	<tr><th scope=row>6077</th><td>Mal     </td><td> 244.3800</td><td>-2.576419</td><td>0.2641796</td><td> -9.752528</td><td>1.799300e-22</td><td>9.198922e-19</td><td> 965</td><td> 360</td><td> 634</td><td>⋯</td><td>  76</td><td> 430.0101</td><td> 438.4547</td><td> 378.6265</td><td> 428.5133</td><td>  87.04242</td><td> 50.41678</td><td>  41.76875</td><td> 100.20705</td><td>ENSMUSG00000027375</td></tr>
	<tr><th scope=row>1883</th><td>Baiap2l2</td><td> 690.0241</td><td> 2.810098</td><td>0.2944714</td><td>  9.542854</td><td>1.389540e-21</td><td>5.668449e-18</td><td> 387</td><td> 168</td><td> 219</td><td>⋯</td><td>1065</td><td> 172.4496</td><td> 204.6122</td><td> 130.7874</td><td> 182.2636</td><td>1008.04531</td><td>638.17029</td><td>1779.64706</td><td>1404.21725</td><td>ENSMUSG00000018126</td></tr>
	<tr><th scope=row>6343</th><td>Tspan2  </td><td> 159.7806</td><td>-3.162569</td><td>0.3320560</td><td> -9.524204</td><td>1.663115e-21</td><td>5.668449e-18</td><td> 677</td><td> 290</td><td> 423</td><td>⋯</td><td>  31</td><td> 301.6755</td><td> 353.1996</td><td> 252.6168</td><td> 243.3413</td><td>  49.40245</td><td> 13.26757</td><td>  23.86786</td><td>  40.87393</td><td>ENSMUSG00000027858</td></tr>
</tbody>
</table>




```R
#just for OCD
all<-all[,c(24,1:23)]
```


```R
head(all)
```


<table>
<caption>A data.frame: 6 × 24</caption>
<thead>
	<tr><th></th><th scope=col>ensembl_ID</th><th scope=col>gene_name</th><th scope=col>Cnp5xFAD_vs_Cnpko_baseMean</th><th scope=col>Cnp5xFAD_vs_Cnpko_log2FoldChange</th><th scope=col>Cnp5xFAD_vs_Cnpko_lfcSE</th><th scope=col>Cnp5xFAD_vs_Cnpko_stat</th><th scope=col>Cnp5xFAD_vs_Cnpko_pvalue</th><th scope=col>Cnp5xFAD_vs_Cnpko_padj</th><th scope=col>Cnp_ko_5.raw_counts</th><th scope=col>Cnp_ko_6.raw_counts</th><th scope=col>⋯</th><th scope=col>Cnp_5xFAD_15.raw_counts</th><th scope=col>Cnp_5xFAD_16.raw_counts</th><th scope=col>Cnp_ko_5._normalised_value</th><th scope=col>Cnp_ko_6._normalised_value</th><th scope=col>Cnp_ko_7._normalised_value</th><th scope=col>Cnp_ko_8._normalised_value</th><th scope=col>Cnp_5xFAD_13._normalised_value</th><th scope=col>Cnp_5xFAD_14._normalised_value</th><th scope=col>Cnp_5xFAD_15._normalised_value</th><th scope=col>Cnp_5xFAD_16._normalised_value</th></tr>
	<tr><th></th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>⋯</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>8346</th><td>ENSMUSG00000031425</td><td>Plp1    </td><td>1884.9768</td><td>-3.936715</td><td>0.2460145</td><td>-16.001960</td><td>1.238158e-57</td><td>2.532033e-53</td><td>8325</td><td>3279</td><td>⋯</td><td> 103</td><td> 273</td><td>3709.6723</td><td>3993.5913</td><td>3421.3746</td><td>3031.5864</td><td> 217.60605</td><td>192.37982</td><td> 153.64933</td><td> 359.95428</td></tr>
	<tr><th scope=row>10784</th><td>ENSMUSG00000037625</td><td>Cldn11  </td><td> 191.1735</td><td>-3.677005</td><td>0.2900269</td><td>-12.678152</td><td>7.815309e-37</td><td>7.991153e-33</td><td> 891</td><td> 205</td><td>⋯</td><td>  18</td><td>  29</td><td> 397.0352</td><td> 249.6756</td><td> 320.6979</td><td> 450.8115</td><td>  23.52498</td><td> 22.55488</td><td>  26.85134</td><td>  38.23690</td></tr>
	<tr><th scope=row>5551</th><td>ENSMUSG00000026442</td><td>Nfasc   </td><td> 349.5555</td><td>-2.956616</td><td>0.2721640</td><td>-10.863364</td><td>1.722839e-27</td><td>1.174402e-23</td><td>2042</td><td> 498</td><td>⋯</td><td>  49</td><td>  70</td><td> 909.9280</td><td> 606.5290</td><td> 569.7314</td><td> 390.7033</td><td>  70.57493</td><td> 83.58571</td><td>  73.09531</td><td>  92.29597</td></tr>
	<tr><th scope=row>6077</th><td>ENSMUSG00000027375</td><td>Mal     </td><td> 244.3800</td><td>-2.576419</td><td>0.2641796</td><td> -9.752528</td><td>1.799300e-22</td><td>9.198922e-19</td><td> 965</td><td> 360</td><td>⋯</td><td>  28</td><td>  76</td><td> 430.0101</td><td> 438.4547</td><td> 378.6265</td><td> 428.5133</td><td>  87.04242</td><td> 50.41678</td><td>  41.76875</td><td> 100.20705</td></tr>
	<tr><th scope=row>1883</th><td>ENSMUSG00000018126</td><td>Baiap2l2</td><td> 690.0241</td><td> 2.810098</td><td>0.2944714</td><td>  9.542854</td><td>1.389540e-21</td><td>5.668449e-18</td><td> 387</td><td> 168</td><td>⋯</td><td>1193</td><td>1065</td><td> 172.4496</td><td> 204.6122</td><td> 130.7874</td><td> 182.2636</td><td>1008.04531</td><td>638.17029</td><td>1779.64706</td><td>1404.21725</td></tr>
	<tr><th scope=row>6343</th><td>ENSMUSG00000027858</td><td>Tspan2  </td><td> 159.7806</td><td>-3.162569</td><td>0.3320560</td><td> -9.524204</td><td>1.663115e-21</td><td>5.668449e-18</td><td> 677</td><td> 290</td><td>⋯</td><td>  16</td><td>  31</td><td> 301.6755</td><td> 353.1996</td><td> 252.6168</td><td> 243.3413</td><td>  49.40245</td><td> 13.26757</td><td>  23.86786</td><td>  40.87393</td></tr>
</tbody>
</table>


